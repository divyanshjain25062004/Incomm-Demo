import { kv } from '@vercel/kv';

export default async function handler(req, res) {
  // Allow CORS for Refold
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const body = req.body;

    // Handle both formats:
    // 1. Direct array of workers: [{...}, {...}]
    // 2. Wrapped object: { mapped_workers: [{...}] } or { body: { mapped_workers: [...] } }
    let workers = [];

    if (Array.isArray(body)) {
      workers = body;
    } else if (body?.mapped_workers) {
      workers = body.mapped_workers;
    } else if (body?.body?.mapped_workers) {
      workers = body.body.mapped_workers;
    } else if (body?.data) {
      workers = Array.isArray(body.data) ? body.data : [body.data];
    } else {
      // Single worker object
      workers = [body];
    }

    // Filter out error objects
    workers = workers.filter(w => !w._error);

    if (workers.length === 0) {
      return res.status(400).json({ error: 'No valid worker data found in request' });
    }

    // Store in KV — merge with existing workers (keyed by Employee ID)
    const existingRaw = await kv.get('workers') || [];
    const existing = Array.isArray(existingRaw) ? existingRaw : [];

    // Build a map of existing workers by Employee ID
    const workerMap = {};
    for (const w of existing) {
      if (w['Employee ID']) workerMap[w['Employee ID']] = w;
    }

    // Upsert incoming workers
    for (const w of workers) {
      const id = w['Employee ID'] || w['employee_id'] || w['Worker_ID'];
      if (id) workerMap[id] = { ...w, _synced_at: new Date().toISOString() };
    }

    const merged = Object.values(workerMap);
    await kv.set('workers', merged);
    await kv.set('last_sync', new Date().toISOString());

    return res.status(200).json({
      success: true,
      received: workers.length,
      total_stored: merged.length,
      synced_at: new Date().toISOString()
    });

  } catch (err) {
    console.error('Ingest error:', err);
    return res.status(500).json({ error: err.message });
  }
}
