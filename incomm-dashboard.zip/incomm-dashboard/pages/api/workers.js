import { kv } from '@vercel/kv';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');

  if (req.method === 'DELETE') {
    await kv.del('workers');
    await kv.del('last_sync');
    return res.status(200).json({ success: true, message: 'All workers cleared' });
  }

  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const workers = await kv.get('workers') || [];
    const lastSync = await kv.get('last_sync') || null;

    return res.status(200).json({
      workers: Array.isArray(workers) ? workers : [],
      total: Array.isArray(workers) ? workers.length : 0,
      last_sync: lastSync
    });
  } catch (err) {
    console.error('Workers fetch error:', err);
    return res.status(500).json({ error: err.message });
  }
}
