# InComm Benefits Census Dashboard

A Vercel-hosted dashboard that receives employee data from Refold and displays it in an InComm-style UI.

## Deploy in 5 steps

### 1. Push to GitHub
Create a new GitHub repo and push this folder to it.

### 2. Import to Vercel
- Go to vercel.com → New Project → Import your GitHub repo
- Framework: Next.js (auto-detected)
- Click Deploy

### 3. Add Vercel KV (Storage)
- In your Vercel project → Storage tab → Create KV Store
- Name it anything (e.g. `incomm-kv`)
- Click Connect → it auto-adds all required env vars

### 4. Redeploy
After connecting KV, trigger a redeploy (Vercel dashboard → Deployments → Redeploy).

### 5. Configure Refold
In your Refold workflow, add an HTTP action after the Custom Code node:
- **Method**: POST
- **URL**: `https://your-app.vercel.app/api/ingest`
- **Headers**: `Content-Type: application/json`
- **Body**: `{{node.3.body}}` (your custom code node output)

---

## API Endpoints

| Endpoint | Method | Description |
|---|---|---|
| `/api/ingest` | POST | Receives worker data from Refold |
| `/api/workers` | GET | Returns all stored workers |
| `/api/workers` | DELETE | Clears all workers |

## Request Format
The `/api/ingest` endpoint accepts any of these formats:
```json
{ "mapped_workers": [...] }
```
```json
[{ "Employee ID": "...", ... }]
```

## Local Development
```bash
npm install
vercel env pull .env.local   # pulls KV env vars
npm run dev
```
