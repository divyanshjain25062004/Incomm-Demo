import { useState, useEffect, useCallback } from 'react';
import Head from 'next/head';

const COLUMNS = [
  { key: 'Employee ID',           label: 'Emp ID',        width: 80  },
  { key: 'First Name',            label: 'First',         width: 90  },
  { key: 'Last Name',             label: 'Last',          width: 110 },
  { key: 'DOB',                   label: 'DOB',           width: 100 },
  { key: 'SSN',                   label: 'SSN',           width: 110 },
  { key: 'Work Email',            label: 'Work Email',    width: 210 },
  { key: 'Mobile Phone Number',   label: 'Mobile',        width: 130 },
  { key: 'Employment Status',     label: 'Status',        width: 90  },
  { key: 'Employment Start Date', label: 'Start Date',    width: 100 },
  { key: 'Employment Term Date',  label: 'Term Date',     width: 100 },
  { key: 'Home Address 1',        label: 'Address 1',     width: 190 },
  { key: 'Home Address 2',        label: 'Address 2',     width: 120 },
  { key: 'City',                  label: 'City',          width: 110 },
  { key: 'State',                 label: 'ST',            width: 50  },
  { key: 'Postal Code',           label: 'ZIP',           width: 70  },
  { key: 'Benefits Account Type', label: 'Benefit Type',  width: 110 },
  { key: 'Coverage Tier',         label: 'Coverage',      width: 110 },
  { key: 'Plan Effective Date',   label: 'Plan Start',    width: 100 },
  { key: 'Plan Term Date',        label: 'Plan End',      width: 100 },
  { key: 'Employer Amount',       label: 'Employer $',    width: 90  },
  { key: 'Employee Amount',       label: 'Employee $',    width: 90  },
  { key: 'Benefits Amount',       label: 'Total $',       width: 90  },
];

const BENEFIT_COLORS = {
  HSA:   { bg: '#E3F2FD', color: '#0057A8', border: '#90CAF9' },
  FSA:   { bg: '#E8F5E9', color: '#00875A', border: '#A5D6A7' },
  DCFSA: { bg: '#FFF3E0', color: '#E65100', border: '#FFCC80' },
};

const STATUS_COLORS = {
  Active:     { bg: '#E8F5E9', color: '#00875A' },
  Terminated: { bg: '#FFEBEE', color: '#DE350B' },
};

function Badge({ value, type }) {
  const colors = type === 'benefit'
    ? (BENEFIT_COLORS[value] || { bg: '#F5F5F5', color: '#666', border: '#DDD' })
    : (STATUS_COLORS[value]  || { bg: '#F5F5F5', color: '#666' });

  return (
    <span style={{
      display: 'inline-block',
      padding: '2px 8px',
      borderRadius: '4px',
      fontSize: '11px',
      fontWeight: '600',
      letterSpacing: '0.3px',
      background: colors.bg,
      color: colors.color,
      border: `1px solid ${colors.border || colors.bg}`,
      whiteSpace: 'nowrap',
    }}>
      {value}
    </span>
  );
}

function MaskSSN({ value, revealed }) {
  if (!value) return <span style={{ color: '#AAB4C4' }}>—</span>;
  if (!revealed) return <span style={{ fontFamily: 'var(--font-mono)', letterSpacing: '1px', color: '#8A96A8' }}>•••-••-{value.slice(-4)}</span>;
  return <span style={{ fontFamily: 'var(--font-mono)' }}>{value}</span>;
}

function Cell({ col, value, showSSN }) {
  if (value === '' || value === null || value === undefined) {
    return <span style={{ color: '#C5CDD8' }}>—</span>;
  }
  if (col.key === 'SSN') return <MaskSSN value={value} revealed={showSSN} />;
  if (col.key === 'Employment Status') return <Badge value={value} type="status" />;
  if (col.key === 'Benefits Account Type' && value) return <Badge value={value} type="benefit" />;
  if (col.key === 'Employer Amount' || col.key === 'Employee Amount' || col.key === 'Benefits Amount') {
    return <span style={{ fontFamily: 'var(--font-mono)', fontSize: '12px' }}>${Number(value).toLocaleString()}</span>;
  }
  if (col.key === 'Work Email') return (
    <span style={{ fontSize: '12px', color: '#0057A8' }}>{value}</span>
  );
  return <span>{value}</span>;
}

export default function Dashboard() {
  const [workers, setWorkers]       = useState([]);
  const [lastSync, setLastSync]     = useState(null);
  const [loading, setLoading]       = useState(true);
  const [syncing, setSyncing]       = useState(false);
  const [showSSN, setShowSSN]       = useState(false);
  const [search, setSearch]         = useState('');
  const [filterStatus, setFilter]   = useState('All');
  const [selectedRow, setSelected]  = useState(null);
  const [notification, setNotif]    = useState(null);
  const [prevCount, setPrevCount]   = useState(0);

  const fetchWorkers = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const r = await fetch('/api/workers');
      const d = await r.json();
      const incoming = d.workers || [];

      if (incoming.length > prevCount && prevCount > 0) {
        setNotif({ type: 'success', msg: `${incoming.length - prevCount} new record(s) synced` });
        setTimeout(() => setNotif(null), 4000);
      }
      setPrevCount(incoming.length);
      setWorkers(incoming);
      setLastSync(d.last_sync);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
      setSyncing(false);
    }
  }, [prevCount]);

  useEffect(() => {
    fetchWorkers();
    const interval = setInterval(() => fetchWorkers(true), 5000);
    return () => clearInterval(interval);
  }, []);

  const handleClear = async () => {
    if (!confirm('Clear all workers from the dashboard?')) return;
    await fetch('/api/workers', { method: 'DELETE' });
    setWorkers([]);
    setPrevCount(0);
    setLastSync(null);
  };

  const filtered = workers.filter(w => {
    const matchStatus = filterStatus === 'All' || w['Employment Status'] === filterStatus;
    const q = search.toLowerCase();
    const matchSearch = !q || [
      w['Employee ID'], w['First Name'], w['Last Name'],
      w['Work Email'], w['City'], w['State'], w['Benefits Account Type']
    ].some(v => v && String(v).toLowerCase().includes(q));
    return matchStatus && matchSearch;
  });

  const stats = {
    total:      workers.length,
    active:     workers.filter(w => w['Employment Status'] === 'Active').length,
    hsa:        workers.filter(w => w['Benefits Account Type'] === 'HSA').length,
    fsa:        workers.filter(w => w['Benefits Account Type'] === 'FSA').length,
    dcfsa:      workers.filter(w => w['Benefits Account Type'] === 'DCFSA').length,
  };

  const detailWorker = selectedRow !== null ? filtered[selectedRow] : null;

  return (
    <>
      <Head>
        <title>InComm Benefits Census | Workforce Data</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </Head>

      <div style={{ minHeight: '100vh', background: '#F0F3F8', fontFamily: 'var(--font-main)' }}>

        {/* TOPBAR */}
        <header style={{
          background: 'var(--ic-navy)',
          borderBottom: '3px solid var(--ic-orange)',
          padding: '0 32px',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          height: '60px', position: 'sticky', top: 0, zIndex: 100,
          boxShadow: '0 2px 12px rgba(0,0,0,0.25)'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <div style={{
                width: '32px', height: '32px', borderRadius: '6px',
                background: 'var(--ic-orange)', display: 'flex', alignItems: 'center', justifyContent: 'center'
              }}>
                <span style={{ color: 'white', fontSize: '16px', fontWeight: '800' }}>IC</span>
              </div>
              <div>
                <div style={{ color: 'white', fontWeight: '700', fontSize: '15px', letterSpacing: '0.5px' }}>InComm Benefits</div>
                <div style={{ color: '#7A9CC4', fontSize: '10px', letterSpacing: '1px', textTransform: 'uppercase' }}>Census Data Platform</div>
              </div>
            </div>
            <div style={{ width: '1px', height: '32px', background: 'rgba(255,255,255,0.15)', margin: '0 8px' }} />
            <span style={{
              background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.15)',
              color: '#A8C4E0', fontSize: '11px', padding: '3px 10px', borderRadius: '4px',
              letterSpacing: '0.5px'
            }}>
              Powered by Refold
            </span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            {lastSync && (
              <div style={{ color: '#7A9CC4', fontSize: '11px', textAlign: 'right' }}>
                <div style={{ color: '#A8C4E0' }}>Last sync</div>
                <div style={{ fontFamily: 'var(--font-mono)' }}>{new Date(lastSync).toLocaleTimeString()}</div>
              </div>
            )}
            <div style={{
              width: '8px', height: '8px', borderRadius: '50%',
              background: '#00D68F',
              boxShadow: '0 0 8px #00D68F',
              animation: 'pulse 2s infinite'
            }} />
            <span style={{ color: '#A8C4E0', fontSize: '11px' }}>Live</span>
          </div>
        </header>

        {/* NOTIFICATION */}
        {notification && (
          <div style={{
            position: 'fixed', top: '72px', right: '24px', zIndex: 200,
            background: '#00875A', color: 'white', padding: '12px 20px',
            borderRadius: '8px', fontSize: '13px', fontWeight: '500',
            boxShadow: '0 4px 16px rgba(0,0,0,0.2)',
            animation: 'slideIn 0.3s ease'
          }}>
            ✓ {notification.msg}
          </div>
        )}

        <div style={{ padding: '24px 32px', maxWidth: '100%' }}>

          {/* STATS ROW */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: '16px', marginBottom: '24px' }}>
            {[
              { label: 'Total Employees', value: stats.total,  accent: 'var(--ic-blue)',   icon: '👥' },
              { label: 'Active',          value: stats.active, accent: '#00875A',           icon: '✓'  },
              { label: 'HSA Enrolled',    value: stats.hsa,    accent: '#0057A8',           icon: '🏦' },
              { label: 'FSA Enrolled',    value: stats.fsa,    accent: '#00875A',           icon: '💊' },
              { label: 'DCFSA Enrolled',  value: stats.dcfsa,  accent: '#E65100',           icon: '👶' },
            ].map(s => (
              <div key={s.label} style={{
                background: 'white', borderRadius: '10px', padding: '20px',
                boxShadow: '0 1px 4px rgba(0,0,0,0.08)',
                borderLeft: `4px solid ${s.accent}`,
              }}>
                <div style={{ fontSize: '11px', color: 'var(--ic-gray-400)', textTransform: 'uppercase', letterSpacing: '0.8px', marginBottom: '8px' }}>
                  {s.icon} {s.label}
                </div>
                <div style={{ fontSize: '32px', fontWeight: '700', color: s.accent, lineHeight: 1 }}>{s.value}</div>
              </div>
            ))}
          </div>

          {/* TOOLBAR */}
          <div style={{
            background: 'white', borderRadius: '10px 10px 0 0',
            padding: '16px 20px', display: 'flex', alignItems: 'center', gap: '12px',
            borderBottom: '1px solid var(--ic-gray-200)',
            boxShadow: '0 1px 4px rgba(0,0,0,0.06)'
          }}>
            <input
              type="text"
              placeholder="Search by name, ID, email, city..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              style={{
                flex: 1, padding: '8px 14px', borderRadius: '6px',
                border: '1.5px solid var(--ic-gray-200)', fontSize: '13px',
                fontFamily: 'var(--font-main)', outline: 'none',
                transition: 'border-color 0.2s',
              }}
              onFocus={e => e.target.style.borderColor = 'var(--ic-blue)'}
              onBlur={e => e.target.style.borderColor = 'var(--ic-gray-200)'}
            />

            <select
              value={filterStatus}
              onChange={e => setFilter(e.target.value)}
              style={{
                padding: '8px 12px', borderRadius: '6px',
                border: '1.5px solid var(--ic-gray-200)', fontSize: '13px',
                fontFamily: 'var(--font-main)', background: 'white', cursor: 'pointer'
              }}
            >
              <option>All</option>
              <option>Active</option>
              <option>Terminated</option>
            </select>

            <button
              onClick={() => setShowSSN(!showSSN)}
              style={{
                padding: '8px 14px', borderRadius: '6px', fontSize: '12px',
                border: '1.5px solid var(--ic-gray-200)',
                background: showSSN ? '#FFF3E0' : 'white',
                color: showSSN ? 'var(--ic-orange)' : 'var(--ic-gray-600)',
                cursor: 'pointer', fontFamily: 'var(--font-main)', fontWeight: '500',
                transition: 'all 0.2s',
              }}
            >
              {showSSN ? '🔒 Mask SSN' : '👁 Show SSN'}
            </button>

            <button
              onClick={() => { setSyncing(true); fetchWorkers(true); }}
              style={{
                padding: '8px 16px', borderRadius: '6px', fontSize: '12px',
                border: 'none', background: 'var(--ic-blue)', color: 'white',
                cursor: 'pointer', fontFamily: 'var(--font-main)', fontWeight: '600',
                display: 'flex', alignItems: 'center', gap: '6px',
                opacity: syncing ? 0.7 : 1, transition: 'opacity 0.2s'
              }}
            >
              {syncing ? '⟳ Syncing...' : '↻ Refresh'}
            </button>

            <button
              onClick={handleClear}
              style={{
                padding: '8px 14px', borderRadius: '6px', fontSize: '12px',
                border: '1.5px solid #FFCDD2', background: '#FFF5F5',
                color: 'var(--ic-red)', cursor: 'pointer', fontFamily: 'var(--font-main)', fontWeight: '500'
              }}
            >
              Clear
            </button>

            <div style={{ marginLeft: 'auto', fontSize: '12px', color: 'var(--ic-gray-400)', whiteSpace: 'nowrap' }}>
              {filtered.length} of {workers.length} records
            </div>
          </div>

          {/* TABLE */}
          <div style={{
            background: 'white',
            borderRadius: '0 0 10px 10px',
            boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
            overflow: 'hidden',
          }}>
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '12px' }}>
                <thead>
                  <tr style={{ background: 'var(--ic-navy)', position: 'sticky', top: '60px' }}>
                    <th style={{ width: '40px', padding: '10px 8px', color: '#7A9CC4', fontSize: '11px', fontWeight: '600' }}>#</th>
                    {COLUMNS.map(col => (
                      <th key={col.key} style={{
                        padding: '10px 12px', textAlign: 'left',
                        color: '#A8C4E0', fontSize: '10px', fontWeight: '600',
                        letterSpacing: '0.6px', textTransform: 'uppercase',
                        minWidth: col.width, whiteSpace: 'nowrap',
                        borderRight: '1px solid rgba(255,255,255,0.06)'
                      }}>
                        {col.label}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr><td colSpan={COLUMNS.length + 1} style={{ padding: '60px', textAlign: 'center', color: 'var(--ic-gray-400)' }}>
                      <div style={{ fontSize: '24px', marginBottom: '12px' }}>⟳</div>
                      Loading census data...
                    </td></tr>
                  ) : filtered.length === 0 ? (
                    <tr><td colSpan={COLUMNS.length + 1} style={{ padding: '80px', textAlign: 'center' }}>
                      <div style={{ fontSize: '40px', marginBottom: '16px' }}>📋</div>
                      <div style={{ color: 'var(--ic-gray-600)', fontWeight: '600', fontSize: '15px', marginBottom: '8px' }}>
                        {workers.length === 0 ? 'No data received yet' : 'No records match your search'}
                      </div>
                      <div style={{ color: 'var(--ic-gray-400)', fontSize: '13px' }}>
                        {workers.length === 0
                          ? 'Waiting for Refold to POST employee data to /api/ingest'
                          : 'Try adjusting your search or filter'}
                      </div>
                    </td></tr>
                  ) : (
                    filtered.map((worker, i) => (
                      <tr
                        key={worker['Employee ID'] || i}
                        onClick={() => setSelected(selectedRow === i ? null : i)}
                        style={{
                          background: selectedRow === i ? '#EEF4FF' : i % 2 === 0 ? 'white' : '#FAFBFC',
                          borderBottom: '1px solid var(--ic-gray-100)',
                          cursor: 'pointer',
                          transition: 'background 0.1s',
                        }}
                        onMouseEnter={e => { if (selectedRow !== i) e.currentTarget.style.background = '#F5F8FF'; }}
                        onMouseLeave={e => { if (selectedRow !== i) e.currentTarget.style.background = i % 2 === 0 ? 'white' : '#FAFBFC'; }}
                      >
                        <td style={{ padding: '9px 8px', textAlign: 'center', color: '#C5CDD8', fontSize: '11px' }}>{i + 1}</td>
                        {COLUMNS.map(col => (
                          <td key={col.key} style={{
                            padding: '9px 12px',
                            borderRight: '1px solid var(--ic-gray-100)',
                            whiteSpace: col.key === 'Work Email' || col.key === 'Home Address 1' ? 'nowrap' : 'nowrap',
                            maxWidth: col.width,
                            overflow: 'hidden', textOverflow: 'ellipsis',
                          }}>
                            <Cell col={col} value={worker[col.key]} showSSN={showSSN} />
                          </td>
                        ))}
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* DETAIL PANEL */}
          {detailWorker && (
            <div style={{
              marginTop: '20px', background: 'white', borderRadius: '10px',
              boxShadow: '0 2px 12px rgba(0,0,0,0.1)', overflow: 'hidden'
            }}>
              <div style={{
                background: 'var(--ic-navy)', padding: '16px 24px',
                display: 'flex', alignItems: 'center', justifyContent: 'space-between'
              }}>
                <div>
                  <div style={{ color: 'white', fontWeight: '700', fontSize: '16px' }}>
                    {detailWorker['First Name']} {detailWorker['Last Name']}
                  </div>
                  <div style={{ color: '#7A9CC4', fontSize: '12px', fontFamily: 'var(--font-mono)' }}>
                    ID: {detailWorker['Employee ID']}
                  </div>
                </div>
                <button onClick={() => setSelected(null)} style={{
                  background: 'rgba(255,255,255,0.1)', border: 'none',
                  color: 'white', padding: '6px 12px', borderRadius: '6px',
                  cursor: 'pointer', fontSize: '13px'
                }}>✕ Close</button>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '0', padding: '0' }}>
                {[
                  { section: 'Personal', fields: ['DOB', 'SSN', 'Mobile Phone Number', 'Work Email'] },
                  { section: 'Employment', fields: ['Employment Status', 'Employment Start Date', 'Employment Term Date'] },
                  { section: 'Address', fields: ['Home Address 1', 'Home Address 2', 'City', 'State', 'Postal Code'] },
                  { section: 'Benefits', fields: ['Benefits Account Type', 'Coverage Tier', 'Plan Effective Date', 'Plan Term Date', 'Employer Amount', 'Employee Amount', 'Benefits Amount'] },
                ].map(section => (
                  <div key={section.section} style={{ padding: '20px 24px', borderRight: '1px solid var(--ic-gray-100)' }}>
                    <div style={{
                      fontSize: '10px', fontWeight: '700', letterSpacing: '1px',
                      textTransform: 'uppercase', color: 'var(--ic-orange)',
                      marginBottom: '14px', paddingBottom: '6px',
                      borderBottom: '2px solid var(--ic-orange)'
                    }}>
                      {section.section}
                    </div>
                    {section.fields.map(field => (
                      <div key={field} style={{ marginBottom: '10px' }}>
                        <div style={{ fontSize: '10px', color: 'var(--ic-gray-400)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '2px' }}>
                          {field}
                        </div>
                        <div style={{ fontSize: '13px', fontWeight: '500', color: 'var(--ic-gray-800)' }}>
                          <Cell col={{ key: field }} value={detailWorker[field]} showSSN={showSSN} />
                        </div>
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ENDPOINT INFO */}
          <div style={{
            marginTop: '20px', background: '#F0F6FF',
            border: '1px solid #BDD4F0', borderRadius: '10px', padding: '16px 24px',
            display: 'flex', alignItems: 'center', gap: '20px', flexWrap: 'wrap'
          }}>
            <div style={{ fontSize: '12px', color: 'var(--ic-blue)', fontWeight: '600', whiteSpace: 'nowrap' }}>
              📡 Refold Endpoint
            </div>
            <code style={{
              flex: 1, fontFamily: 'var(--font-mono)', fontSize: '12px',
              color: 'var(--ic-navy)', background: 'white',
              padding: '8px 14px', borderRadius: '6px',
              border: '1px solid #BDD4F0', userSelect: 'all'
            }}>
              POST {typeof window !== 'undefined' ? window.location.origin : 'https://your-app.vercel.app'}/api/ingest
            </code>
            <div style={{ fontSize: '11px', color: 'var(--ic-gray-400)' }}>
              Auto-refreshes every 5s
            </div>
          </div>

        </div>
      </div>

      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.4; }
        }
        @keyframes slideIn {
          from { transform: translateX(20px); opacity: 0; }
          to   { transform: translateX(0);   opacity: 1; }
        }
        ::-webkit-scrollbar { height: 6px; width: 6px; }
        ::-webkit-scrollbar-track { background: #F0F3F8; }
        ::-webkit-scrollbar-thumb { background: #C5CDD8; border-radius: 3px; }
        ::-webkit-scrollbar-thumb:hover { background: #8A96A8; }
      `}</style>
    </>
  );
}
